self.__NEXT_FONT_MANIFEST={
  "pages": {},
  "app": {
    "/app/node_modules/next/font/google/target.css?{\"path\":\"src/app/layout.tsx\",\"import\":\"Roboto\",\"arguments\":[{\"subsets\":[\"latin\"],\"weight\":[\"300\",\"400\",\"500\",\"700\",\"900\"],\"display\":\"swap\"}],\"variableName\":\"roboto\"}": [
      "static/media/47cbc4e2adbc5db9-s.p.woff2"
    ]
  },
  "appUsingSizeAdjust": true,
  "pagesUsingSizeAdjust": false
}